#include "libft.h"

int	ft_printptr(unsigned long long ptr)
{
	int	count;

	count = 0;
	count += ft_printstr("0x");
	count += ft_printhexa(ptr, 'x');
	return (count);
}