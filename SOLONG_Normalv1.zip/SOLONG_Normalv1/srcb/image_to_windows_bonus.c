/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   image_to_windows_bonus.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/17 10:46:57 by marvin            #+#    #+#             */
/*   Updated: 2024/06/17 10:46:57 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long_bonus.h"

int image_to_window(t_game *game)
{
    int i;
    int j;

    j = 0;
    while (game->map[j] != NULL)
    {
        i = 0;
        while (game->map[j][i] != '\n' && game->map[j][i] != '\0')
        {
            mlx_image_to_window(game->mlx, game->img_floor, i * 48, j * 48);
            if (game->map[j][i] == '1')
                mlx_image_to_window(game->mlx, game->img_wall, i * 48, j * 48);
            if (game->map[j][i] == 'C')
                mlx_image_to_window(game->mlx, game->img_coin, i * 48, j * 48);
            if (game->map[j][i] == 'P')
                mlx_image_to_window(game->mlx, game->img_p_left, i * 48, j * 48);
            if (game->map[j][i] == 'E')
                mlx_image_to_window(game->mlx, game->img_closehouse, i * 48, j * 48);
            if (game->map[j][i] == 'M')
                mlx_image_to_window(game->mlx, game->img_enemy, i * 48, j * 48);
            i++;
        }
        j++;
    }
    return (EXIT_SUCCESS);
}
