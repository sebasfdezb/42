/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   enemy_move_bonus.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/19 11:31:28 by marvin            #+#    #+#             */
/*   Updated: 2024/06/19 11:31:28 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long_bonus.h"

static void	move_previous_images(t_game *game)
{
	if (game->map[game->e_position.y][game->e_position.x] == 'E')
	{
		mlx_image_to_window(game->mlx, game->img_closehouse, game->e_position.x * 48,
			game->e_position.y * 48);
		if (game->coin == game->coin_copy)
			mlx_image_to_window(game->mlx, game->img_openhouse, game->e_position.x * 48,
				game->e_position.y * 48);
	}
	if (game->map[game->e_position.y][game->e_position.x] != 'E')
	{
		mlx_image_to_window(game->mlx, game->img_floor, game->e_position.x * 48,
			game->e_position.y * 48);
		if (game->map[game->e_position.y][game->e_position.x] == 'C'
			&& game->coin != game->coin_copy)
			mlx_image_to_window(game->mlx, game->img_coin, game->e_position.x * 48,
				game->e_position.y * 48);
	}
}

static void	move_images(t_game *game, int x, int y, void *img)
{
	if (game->map[y][x] != '1')
	{
		move_previous_images(game);
		game->e_position.x = x;
		game->e_position.y = y;
		if (game->map[game->e_position.y][game->e_position.x] == 'E')
		{
			mlx_image_to_window(game->mlx, game->img_closehouse, game->e_position.x * 48,
				game->e_position.y * 48);
			if (game->coin == game->coin_copy)
				mlx_image_to_window(game->mlx, game->img_openhouse, game->e_position.x * 48,
					game->e_position.y * 48);
		}
		if (game->map[game->e_position.y][game->e_position.x] != 'E')
		{
			mlx_image_to_window(game->mlx, game->img_floor, game->e_position.x * 48,
				game->e_position.y * 48);
			if (game->map[game->e_position.y][game->e_position.x] == 'C'
				&& game->coin != game->coin_copy)
				mlx_image_to_window(game->mlx, game->img_coin, game->e_position.x * 48,
					game->e_position.y * 48);
		}
		mlx_image_to_window(game->mlx, img, game->e_position.x * 48,
			game->e_position.y * 48);
	}
}

void	calculate_direction(t_game *game, int *dx, int *dy)
{
	*dx = (game->p_position.x) - (game->e_position.x);
	*dy = (game->p_position.y) - (game->e_position.y);
}

void	direction_enemy(t_game *g, int dx, int dy)
{
	if (dx > 0)
		move_images(g, g->e_position.x + 1, g->e_position.y, g->img_enemy);
	if (dx < 0)
		move_images(g, g->e_position.x - 1, g->e_position.y, g->img_enemy);
	if (dy > 0)
		move_images(g, g->e_position.x, g->e_position.y + 1, g->img_enemy);
	if (dy < 0)
		move_images(g, g->e_position.x, g->e_position.y - 1, g->img_enemy);
}

void	enemy_move(t_game *game)
{
	int	dx;
	int	dy;

	calculate_direction(game, &dx, &dy);
	game->enemy_move_timer += game->mlx->delta_time;
	if (game->enemy_move_timer >= 0.5)
	{
		direction_enemy(game, dx, dy);
		game->enemy_move_timer = 0;
	}
	if (game->e_position.x == game->p_position.x
		&& game->e_position.y == game->p_position.y)
	{
		ft_printf("\n");
		ft_printf("MORISTE :(\n");
		ft_printf("\n");
		mlx_close_window(game->mlx);
	}
}
