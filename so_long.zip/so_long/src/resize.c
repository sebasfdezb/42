/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   resize.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sebferna <sebferna@student.42malaga.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/24 11:23:06 by sebferna          #+#    #+#             */
/*   Updated: 2024/04/24 11:23:06 by sebferna         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void    resize_window(int width, int height, void *param)
{
    (void)width;
    (void)height;
    (void)param;
    mlx_set_setting(MLX_STRETCH_IMAGE, 1);
}


