#include "libft.h"

int	ft_putnbr(long int nbr)
{
	int		result;
	char	c;

	result = 0;
	if (nbr < 0)
	{
		result += ft_putchar('-');
		if (result == -1)
			return (-1);
		nbr = -nbr;
	}
	if (nbr > 9)
	{
		result += ft_putnbr(nbr / 10);
		if (result == -1)
			return (-1);
	}
	c = nbr % 10 + '0';
	result += ft_putchar(c);
	if (result == -1)
		return (-1);
	return (result);
}